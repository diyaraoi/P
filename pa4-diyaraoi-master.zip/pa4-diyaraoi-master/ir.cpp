#include<stdio.h>
#include<string.h>
#include <iostream> 
#include <sstream> 
#include <fstream>
#include <bits/stdc++.h> 
#include<string>
std::string op,arg11,arg12,result,rest;
std::string arg1[10];
int reg;
using namespace std;
int main(int argc,char *argv[])
{
  FILE *fp1,*fp2;
  fp2=fopen("output.txt","w");

std::ifstream infile1("compout");
ofstream ou;
ou.open(argv[1]);
  string line1;
while (getline(infile1, line1))
{

ou<<line1<<endl;

}
infile1.close();


std::ifstream infile("compout");
  string line;
while (getline(infile, line))
{
istringstream ss(line); 

	int h=0;
    do { 
        ss >> arg1[h];
	h++;

    } while (ss); 
	int pos = line.find("Incoming");
	line = line.substr(0,pos-1);

  	if(arg1[0].compare(";STOREI")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}
      ou<<"move"<<" "<<arg1[1]<<" "<<arg1[2]<<endl;}








	if(arg1[0].compare(";STOREF")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}
      ou<<"move"<<" "<<arg1[1]<<" "<<arg1[2]<<endl;}




if(arg1[0].compare(";WRITEI")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	
      ou<<""<<"sys writei "<<arg1[1]<<endl;}

if(arg1[0].compare(";READI")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	
      ou<<""<<"sys readi "<<arg1[1]<<endl;}
if(arg1[0].compare(";READF")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	
      ou<<""<<"sys readf "<<arg1[1]<<endl;}


if(arg1[0].compare(";WRITEF")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	
      ou<<""<<"sys writer "<<arg1[1]<<endl;}


if(arg1[0].compare(";WRITES")==0)
    {




      if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	
      ou<<""<<"sys writes "<<arg1[1]<<endl;}



















    

    
	if(arg1[0].compare(";MULTI")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"muli"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }
	if(arg1[0].compare(";DIVI")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"divi"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }
	if(arg1[0].compare(";ADDI")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"addi"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }	



	if(arg1[0].compare(";SUBI")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	stringstream geek(sub); 
    	int x = 0; 
    	geek >> x;
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"subi"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }	


























	if(arg1[0].compare(";ADDF")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"addr"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }



if(arg1[0].compare(";SUBF")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"subr"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }











	if(arg1[0].compare(";MULTF")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"mulr"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }






	if(arg1[0].compare(";DIVF")==0)
    {
	if(arg1[1].at(0) == '$'){int pos = arg1[1].find("T");string sub = arg1[1].substr(pos + 1);
	float x = std::stof(sub);
	x = x-1; 
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[1] ="r"+str1.str();
	}
	if(arg1[2].at(0) == '$'){int pos = arg1[2].find("T");string sub = arg1[2].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[2] ="r"+str1.str();
	}

	if(arg1[3].at(0) == '$'){int pos = arg1[3].find("T");string sub = arg1[3].substr(pos + 1);
	float x = std::stof(sub);
 	x = x-1;
	ostringstream str1; 
  
    // Sending a number as a stream into output 
    // string 
    	str1 << x; 
	arg1[3] ="r"+str1.str();
	}
	ou<<"move"<<" "<<arg1[1]<<" "<<arg1[3]<<endl;
	ou<<"divr"<<" "<<arg1[2]<<" "<<arg1[3]<<endl;

    }









}
ou<<"sys halt"<<endl;
    //fclose(fp1);
    fclose(fp2);
}
