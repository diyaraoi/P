./cfc $1 compout
g++ ir.cpp
./a.out $2
